<?php
// Heading
$_['text_extension']   = 'Extensions';
$_['text_module']      = 'Modules';
$_['text_edit'] = $_['heading_title'] = 'Shipping page Product';
$_['geo_description'] = 'You need of geo informations to calcule the shipping? If yes : It will be shown the fields Country and Region / State';
$_['geo_need'] = "Needs of Geo Zone?";

$_['text_yes'] = "Yes";
$_['text_no'] = "No";

$_['entry_status'] = "Enabled?";
$_['entry_header'] = "Text show in content:";
$_['entry_popup'] = "Text in popup:";
$_['text_success'] = "Save with success!";

$_['button_save'] = "Save";
$_['button_cancel'] = "Cancel";
$_['button_remove'] = "Remove";

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify account module!';
?>
